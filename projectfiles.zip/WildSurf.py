import Firebase
exit = 'no'
listofPossibleAnimals=[]
plantsArray = []
otherLst = []
outputList = []
while True:
    firstQuestion = input("Did you see a plant or an animal? ")
    if firstQuestion == "plant":
        listOfPossiblePlants = Firebase.plantLstDict  
        color = input("What is the color of the plant? ")
        outputList = []
        for i in range(len(plantsArray)):
            listOfColors = plantsArray[i]["Color"]
            for j in range (len(listOfColors)):
                if(color == listOfColors[j]):
                    outputList.append(plantsArray[i])
        plantsArray = outputList
        outputList = []
        
        shape = input("What is the shape? ")
        outputList = []
        for i in range (len(plantsArray)):
            lstOfShapes = plantsArray[i]['Shape']
            for j in range (len(lstOfShapes)):
                if(shape == lstOfShapes[j]):
                    outputList.append(plantsArray[i])
        plantsArray = outputList
        outputList = []

        category = input("What is the category of the specimen you saw? ")
        outputList = []
        for i in range(len(plantsArray)):
            lstOfCategory = plantsArray[i]["Category"]
            for j in range(len(lstOfCategory)):
                if(category == lstOfCategory[j]):
                    outputList.append(plantsArray[i])
        plantsArray = outputList
        outputList = []

        if len(plantsArray)==1:
            finalGuess= plantsArray[0]['name']
            print("The plant you have spotted may potentially be a " + finalGuess)
            exit = input("Would you like to describe another plant or animal?")
            if exit == "yes":
                continue
            else:
                break


    if firstQuestion == "animal":
        listofPossibleAnimals = Firebase.animalLstDict
        color = input("What color is the animal? ")
        for i in range(len(listofPossibleAnimals)):
            lstOfColors = listofPossibleAnimals[i]['color']
            for j in range(len(lstOfColors)):
                if(color==lstOfColors[j]):
                    otherLst.append(listofPossibleAnimals[i])  
        listofPossibleAnimals = otherLst
        otherLst = []
        tails = input("Does it have a tail, yes or no?: ")
        if(tails=='yes'):
            tails = input("Is the tail long or short?: ")
            if tails=='short':
                otherLst = []
                for i in range(len(listofPossibleAnimals)):
                    lst = listofPossibleAnimals[i]['physical attribute']
                    for j in range(len(lst)):
                        if 'short tail'==lst[j]:
                            otherLst.append(listofPossibleAnimals[i])
            else:
                otherLst = []
                for i in range(len(listofPossibleAnimals)):
                    lst = listofPossibleAnimals[i]['physical attribute']
                    for j in range(len(lst)):
                        if 'long tail'==lst[j]:
                            otherLst.append(listofPossibleAnimals[i]) 
        else:
            otherLst = []
            for i in range(len(listofPossibleAnimals)):
                lst = listofPossibleAnimals[i]['physical attribute']
                for j in range(len(lst)):
                    if 'long tail'!=lst[j] and lst[j]!='short tail':
                        otherLst.append(listofPossibleAnimals[i]) 
        listofPossibleAnimals = otherLst
        otherLst = []
        wings = input("Does your animal have wings? ")
        if(wings=='yes'):
            for i in range(len(listofPossibleAnimals)):
                lst = listofPossibleAnimals[i]['physical attribute']
                for j in range(len(lst)):
                    if 'wings'==lst[j]:
                        otherLst.append(listofPossibleAnimals[i]) 
        else:
            for i in range(len(listofPossibleAnimals)):
                lst = listofPossibleAnimals[i]['physical attribute']
                for j in range(len(lst)):
                    if 'wings'!=lst[j]:
                        otherLst.append(listofPossibleAnimals[i])
        listofPossibleAnimals = otherLst 
        otherLst = []
        size = input("What is the size of the animal: big, small, medium? ")
        if size=='big':
            for i in range(len(listofPossibleAnimals)):
                size = listofPossibleAnimals[i]['size']
                for j in range(len(size)):
                    if 'big'==size[j]:
                        otherLst.append(listofPossibleAnimals[i]) 
        elif size=='small':
            for i in range(len(listofPossibleAnimals)):
                size = listofPossibleAnimals[i]['size']
                for j in range(len(size)):
                    if 'small'==size[j]:
                        otherLst.append(listofPossibleAnimals[i]) 
        elif size=='medium':
            for i in range(len(listofPossibleAnimals)):
                size = listofPossibleAnimals[i]['size']
                for j in range(len(size)):
                    if 'medium'==size[j]:
                        otherLst.append(listofPossibleAnimals[i]) 
        listofPossibleAnimals = otherLst 
        print(listofPossibleAnimals)
        otherLst = []
        #Finished general questions
        if len(listofPossibleAnimals)==1:
            finalGuess= listofPossibleAnimals[0]['name']
            print("You might have seen a " + finalGuess)
            exit = input("Want to describe another plant or animal?")
            if exit=='yes':
                continue
            elif exit=='no':
                break
        elif len(listofPossibleAnimals)==0:
            print("Could not match with an animal in our database")
            exit = input("Want to describe another plant or animal?")
            if exit=='yes':
                continue
            elif exit=='no':
                break
        #take out this if statement when we implement while loop
        while len(listofPossibleAnimals)!=1:
            otherLst = []
            beak = input("Does the animal have a beak?: ")
            if beak == 'yes':
                beakLength = input("Is the beak short or long?: ")
                if beakLength=='long':
                    for i in range(len(listofPossibleAnimals)):
                        beakL = listofPossibleAnimals[i]['physical attribute']
                        for j in range(len(beakL)):
                            if 'long beak'==beakL[j]:
                                otherLst.append(listofPossibleAnimals[i])
                elif beakLength=='short':
                    for i in range(len(listofPossibleAnimals)):
                        beakL = listofPossibleAnimals[i]['physical attribute']
                        if 'short beak' in beakL:
                            otherLst.append(listofPossibleAnimals[i])
            elif beak == 'no':
                for dictionary in listofPossibleAnimals:
                    if 'long beak' not in dictionary['physical attribute'] and 'short beak' not in dictionary['physical attribute']:
                        otherLst.append(dictionary)
            listofPossibleAnimals = otherLst
            otherLst = []
            print(listofPossibleAnimals)
            hair = input("Does the animal have fur, feathers, or hairless: ")
            if hair=='fur':
                for dictionary in listofPossibleAnimals:
                    attributeList = dictionary['physical attribute'] 
                    if hair in attributeList:
                        otherLst.append(dictionary)
                listofPossibleAnimals=otherLst
                otherLst = []
                print(listofPossibleAnimals)   
                pattern = input("What pattern is on its fur (spotted, smooth, striped): ")
                if pattern == 'spotted':
                    for dictionary in listofPossibleAnimals:
                        attributeList = dictionary['physical attribute']
                        if 'spotted' in attributeList:
                            otherLst.append(dictionary)
                elif pattern == 'striped':
                        for dictionary in listofPossibleAnimals:
                            attributeList = dictionary['physical attribute']
                        if 'striped' in attributeList:
                            otherLst.append(dictionary) 
                elif pattern == 'smooth':
                        for dictionary in listofPossibleAnimals:
                            attributeList = dictionary['physical attribute']
                            if 'smooth' in attributeList:
                                otherLst.append(dictionary)   
            elif hair=='feathers':
                for dictionary in listofPossibleAnimals:
                    attributeList = dictionary['physical attribute'] 
                    if hair in attributeList:
                        otherLst.append(dictionary)
                listofPossibleAnimals=otherLst
                otherLst = []     
                pattern = input("What pattern is on its feathers (spotted, smooth, striped): ")
                if pattern == 'spotted':
                    for dictionary in listofPossibleAnimals:
                        attributeList = dictionary['physical attribute']
                        if 'spotted' in attributeList:
                            otherLst.append(dictionary)
                elif pattern == 'striped':
                        for dictionary in listofPossibleAnimals:
                            attributeList = dictionary['physical attribute']
                        if 'striped' in attributeList:
                            otherLst.append(dictionary) 
                elif pattern == 'smooth':
                    for dictionary in listofPossibleAnimals:
                        attributeList = dictionary['physical attribute']
                        if 'smooth' in attributeList:
                            otherLst.append(dictionary) 
            elif hair=='hairless':
                for dictionary in listofPossibleAnimals:
                    attributeList = dictionary['physical attribute'] 
                    if hair in attributeList:
                        otherLst.append(dictionary)
                listofPossibleAnimals=otherLst
                otherLst = []     
                pattern = input("What pattern is on its skin (spotted, smooth, striped): ")
                if pattern == 'spotted':
                    for dictionary in listofPossibleAnimals:
                        attributeList = dictionary['physical attribute']
                        if 'spotted' in attributeList:
                            otherLst.append(dictionary)
                elif pattern == 'striped':
                        for dictionary in listofPossibleAnimals:
                            attributeList = dictionary['physical attribute']
                        if 'striped' in attributeList:
                            otherLst.append(dictionary) 
                elif pattern == 'smooth':
                        for dictionary in listofPossibleAnimals:
                            attributeList = dictionary['physical attribute']
                        if 'smooth' in attributeList:
                            otherLst.append(dictionary)
            listofPossibleAnimals = otherLst
            print(listofPossibleAnimals)                                                                         
            print("Could not narrow down the list, here is the list of animals you could have possibly seen: \n")
            for dictionary in listofPossibleAnimals:
                print(dictionary['name']+'\n')
            exit = input("Want to describe another plant or animal?")
            if exit=='yes':
                continue
            elif exit=='no':
                break
            break